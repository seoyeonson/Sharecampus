
$(document).ready(function () {

    $('.img_heart').on({
        'click': function () {
            var src = ($(this).attr('src') === 'img/heart-empty.png')
                ? 'img/heart-red.png'
                : 'img/heart-empty.png';
            $(this).attr('src', src);
        }
    });
});
