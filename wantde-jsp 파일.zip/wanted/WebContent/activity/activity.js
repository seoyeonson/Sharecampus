function newPage() {
    window.location.href = 'activity_info.html'
}
